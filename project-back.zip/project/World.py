class World:
    #TODO set rectangle instead of square
    def __init__(self, length, width, landmarks):
        self.length = length
        self.width = width
        self.landmarks = landmarks